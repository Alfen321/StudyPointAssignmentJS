package other;



public class Joke {

String creator;
String joke;
int id;

    public Joke(String creator, String joke, int id) {
        this.creator = creator;
        this.joke = joke;
        this.id = id;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public void setJoke(String joke) {
        this.joke = joke;
    }

    public void setId(int id) {
        this.id = id;
    }    
}
