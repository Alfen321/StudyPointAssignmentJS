package other;

public class Time {

    String HH;
    String MM;
    String SS;

    public Time(String HH, String MM, String SS) {
        this.HH = HH;
        this.MM = MM;
        this.SS = SS;
    }

    public void setHH(String HH) {
        this.HH = HH;
    }

    public void setMM(String MM) {
        this.MM = MM;
    }

    public void setSS(String SS) {
        this.SS = SS;
    }   
}
