package Servlets;


import other.Joke;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author T430
 */
@WebServlet(urlPatterns = {"/randomJokeAPI"})
public class randomJokeAPI extends HttpServlet {

    Gson gson = new Gson();
    
    private static List<Joke> jokesList = new ArrayList<Joke>(){
        {
            add(new Joke("Tjalfe", "Hvad kalder man en død baby der hænger på en væg fastgjort med søm?\n" +
"– Kunst.", 1));
            add(new Joke("David", "Hvad er det der er rødt og svinger frem og tilbage?\n" +
"– En baby på en kødkrog.", 2));
            add(new Joke("David", "Hvordan får man en baby til at græde ?\n" +
"– Man tørrer blodet på pikken af i dens bamse.", 3));
        }
    };
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        try (PrintWriter out = response.getWriter()) {
            
            
            String jsonReturn = gson.toJson(jokesList, List.class);
            
            out.print(jsonReturn);
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
