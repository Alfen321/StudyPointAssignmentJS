function getQuote() {
    var url = 'http://localhost:8080/AJAXandDOMmanipulation/randomJokeAPI';
    var conf = { method: 'get' };
    var promise = fetch(url, conf);
    promise.then(function (response) {
        return response.json();
    }).then(function (json) {
        console.log(json[0].joke);
        updateDivWithQuote(json[1].joke, 'Quote');
    });
}

function getServerTime() {
    var url = 'http://localhost:8080/AJAXandDOMmanipulation/serverTimeAPI';
    var conf = { method: 'get' };
    var promise = fetch(url, conf);
    promise.then(function (response) {
        return response.json();
    }).then(function (json) {
        console.log(json[0].HH + ":" + json[0].MM + ":" + json[0].SS);
        updateDivWithQuote(json[0].HH + ":" + json[0].MM + ":" + json[0].SS, 'ServerTime');
    });
}

function getDummyPerson() {
    var url = 'http://localhost:8080/AJAXandDOMmanipulation/dummyPersonAPI';
    var conf = { method: 'get' };
    var promise = fetch(url, conf);
    promise.then(function (response) {
        return response.json();
    }).then(function (json) {
        console.log(json);
        console.log(json[0].name);
        document.getElementById('table').innerHTML = table(json);
    });
}

var table = function (array) {
    var content = "<thead   ><tr>";
    for (item in array[0]) {
        content += "<th>" + item + "</th>"
    }
    content += "</tr></thead>";
    var mapped = array.map(
        function (items) {
            var list = "<tr>";
            for (key in items) {
                list += "<td>" + items[key] + "</td>"
            }
            list += "</tr>";
            return list;
        }
    );
    var joined = mapped.join("");
    return "<table>" + content + joined + "</table>";
};

function inputUser(event) {
    var url = 'http://localhost:8080/AJAXandDOMmanipulation/dummyPost';
    var conf = {
        method: 'post',
        body: JSON.stringify({name: document.getElementById('name').value, gender:  document.getElementById('gender').value})
    };
    var promise = fetch(url, conf);
    promise.then(function (response) {
    }).then(function (json) {
        getDummyPerson();
    });
    event.preventDefault();
}

function updateDivWithQuote(quote, callback) {
    var div = document.getElementById(callback);
    div.innerHTML = quote;
}

setInterval(function () {
    getServerTime();
    console.log('Time passed, time update!');
}, 1000)

setInterval(function () {
    getQuote();
    console.log('Time passed, quote update!');
}, 3600000)